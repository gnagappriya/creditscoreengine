package com.creditscore.engine.repository;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
/*
 * The class connects with Database and get the Credit score
 */
@Repository
@Transactional
public class CreditScoreEngineRepository {
	
	 @Autowired
	 private SessionFactory sessionFactory;
	 
	 
	/*
	 * The method gets Credit Score from Database
	 * @param creditRequest
	 * @return creditScore
	 */
	public CreditScore getCreditScore(CreditRequest creditRequest) {
		//sessionFactory.getCurrentSession().saveOrUpdate(creditRequest);
		Query query = sessionFactory.getCurrentSession().createQuery("select * from credit_score where ssn_number = :ssn_number");
		query.setParameter("ssn_number", creditRequest.getSsnNumber());
		return (CreditScore) query.getResultList().get(0);
	}
	 
	/*
	 * The method gets Credit Score from Database
	 * @param creditRequest
	 * @return creditScore
	 */
	public CreditScore saveCreditScore(CreditScore creditScore) {
		sessionFactory.getCurrentSession().saveOrUpdate(creditScore);
		return null;
	}

	public CreditScore getCreditScoreForSsn(String ssn) {
		Query query = sessionFactory.getCurrentSession().createQuery("select * from credit_score where ssn_number = :ssn_number");
		query.setParameter("ssn_number", ssn);
		return (CreditScore) query.getResultList().get(0);
	}
}
