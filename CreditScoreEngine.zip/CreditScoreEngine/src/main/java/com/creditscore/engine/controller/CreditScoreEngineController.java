package com.creditscore.engine.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.creditscore.engine.pojo.CreditRequest;
import com.creditscore.engine.pojo.CreditScore;
import com.creditscore.engine.service.CreditScoreEngineService;


/*
 * The service accepts credit request and generate credit score response
 */
@RestController
public class CreditScoreEngineController {

	private final Logger logger = LoggerFactory.getLogger(CreditScoreEngineController.class);
	
	@Autowired
	CreditScoreEngineService creditScoreEngineService;
	/*
	 * getCreditRequest send credit request and get Credit Score Response
	 * @param  creditReq
	 * @return creditScore
	 */
	@GetMapping("getCreditScore/{ssn}")
	public ResponseEntity<CreditScore> getCreditScore(@RequestBody String ssn ) {
		logger.debug("CreditDecisionEngineController : creditRequest - starts ");
		CreditScore creditScore = creditScoreEngineService.getcreditScoreForSsn(ssn);
		logger.debug("CreditDecisionEngineController : creditRequest - creditRequest ",creditScore);
		logger.debug("CreditDecisionEngineController : creditRequest - end ");
		return  new ResponseEntity<CreditScore>(creditScore,HttpStatus.OK);
	}
	
	@GetMapping("getCreditScore}")
	public ResponseEntity<CreditScore> creditRequest(@RequestBody CreditRequest creditRequest ) {
		logger.debug("CreditDecisionEngineController : creditRequest - starts ");
		CreditScore creditScore = creditScoreEngineService.getcreditScore(creditRequest);
		logger.debug("CreditDecisionEngineController : creditRequest - creditRequest ",creditScore);
		logger.debug("CreditDecisionEngineController : creditRequest - end ");
		return  new ResponseEntity<CreditScore>(creditScore,HttpStatus.OK);
	}
	@PostMapping("saveScore")
	public ResponseEntity<String> saveCreditScore(@RequestBody CreditScore creditScore ) {
		logger.debug("CreditDecisionEngineController : creditScore - starts ");
		creditScoreEngineService.savecreditScore(creditScore);
		logger.debug("CreditDecisionEngineController : creditScore - creditScore ",creditScore);
		logger.debug("CreditDecisionEngineController : creditScore - end ");
		return  new ResponseEntity<String>(creditScore.getSsnNumber()+"Credit score saved successfully in to Database",HttpStatus.OK);
	}
}
